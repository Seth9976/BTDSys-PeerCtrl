// stdafx.cpp : source file that includes just the standard includes
//	Test Plugin 2.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



